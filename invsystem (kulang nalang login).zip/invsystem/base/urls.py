from django.urls import path
from . import views


urlpatterns = [
    
    path('products/', views.products, name="products"),
    path('products/add/', views.add_product, name='add_product'),
    path('products/update/<int:id>/', views.update_product, name='update_product'),
    path('products/delete/<int:id>/', views.delete_product, name='delete_product'),
    path('inventory/', views.inventory, name="inventory"),
    path('inventory/<int:id>', views.update_stock, name='update_stock'),
    path('inventory/order/<int:id>', views.order, name='order'),
    path('sales/', views.sales, name="sales"),
    path('account/', views.account, name="account"),

    
]