from django.shortcuts import render, redirect
from .models import Product, Stock
from django.contrib.auth.decorators import login_required

def products(request):
    products = Product.objects.all()
    context = {
        'products': products,
    }
    return render (request, 'products.html', context)

def add_product(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        price  = request.POST.get('price')
        description = request.POST.get('description')
        product = Product(name=name, price=price, description=description)
        product.save()
        stock = Stock(productstock_id=product.id)
        stock.save()
        return redirect ('/products')
    return render(request, 'addproduct.html')


def delete_product(request,id):
        product = Product.objects.get(id=id)
        context = {
            'product' : product,
        }
        if request.method == 'POST':
            product.delete()
            return redirect('/products')
        return render(request, 'deleteproduct.html', context)

def update_product(request, id):
    update_product = Product.objects.get(id = id)
    if request.method == 'POST':
        update_product.name = request.POST.get('name')
        update_product.price = request.POST.get('price')
        update_product.description = request.POST.get('description')
        update_product.save()

        return redirect('/products')

    context = {
            'update_product':update_product,
         }
    return render(request, 'updateproduct.html', context)


def inventory(request):
    stock = Stock.objects.all()
    products = Product.objects.all()
    context = {
        'products': products,
        'stock': stock,
    }
    return render (request, 'inventory.html', context)


def update_stock(request, id):
    
    products = Product.objects.get(id=id)
    stocks = Stock.objects.get(productstock_id=id)
    if request.method == 'POST':
       
        stocks.stock = request.POST.get('stock')
        stocks.save()
        return redirect('/inventory')

    context = {
        'products' : products,
    }
    return render(request, 'updatestock.html', context)


def sales(request):
    stock = Stock.objects.all()
    products = Product.objects.all()
    context = {
        'products': products,
        'stock': stock,
    }
    return render (request, 'sales.html', context)


def order(request, id):
    
    product = Product.objects.get(id=id)
    stocks = Stock.objects.get(productstock_id=id)
    if request.method == 'POST':
       
        stocks.qty = request.POST.get('stock')
        stocks.save()
        return redirect('/sales')

    context = {
        'product' : product,
    }
    return render(request, 'order.html', context)

def account(request):
    return render(request, 'account.html')