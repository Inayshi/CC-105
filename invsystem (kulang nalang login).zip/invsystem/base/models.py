from operator import mod
from unittest.util import _MAX_LENGTH
from django.db import models
from django.utils import timezone


# Create your models here.
class Product(models.Model):
    name = models.CharField(max_length = 100)
    price = models.IntegerField()
    description = models.CharField(max_length = 100)
   

class Stock(models.Model):
    stock = models.IntegerField(default=0)
    productstock = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='productstock')
    qty = models.IntegerField(default=0)
    date_created = models.DateTimeField(default=timezone.now)
    date_updated = models.DateTimeField(auto_now=True)

